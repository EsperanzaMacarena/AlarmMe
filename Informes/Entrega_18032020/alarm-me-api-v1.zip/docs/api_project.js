define({
  "name": "alarmme-api",
  "version": "1.0.0",
  "description": "",
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2020-03-16T10:01:06.678Z",
    "url": "http://apidocjs.com",
    "version": "0.20.0"
  }
});
